function [exectime, data] = msgRcvCtrl(seg, data)

ttCreateJob('pid_task')
exectime = -1;
