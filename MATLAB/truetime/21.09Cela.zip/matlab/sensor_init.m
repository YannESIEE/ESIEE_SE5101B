function sensor_init(arg)

% Distributed control system: sensor node
%
% Samples the plant periodically and sends the samples to the 
% controller node.

% Initialize TrueTime kernel
Synthese;
ttInitKernel(2, 1, 'prioFP'); % nbrOfInputs, nbrOfOutputs, fixed priority


%%%%%%%%%%%%%%%%%%%%%%%
% Controller parameters
T_ech = 0.010;

data.Adc=Adc;
data.Bdc=Bdc;
data.Cdc=Cdc;
dada.Ddc=Ddc;

data.x=[0 0 0 0]';
data.y=[0 0]';
data.u=0;

%%%%%%%%%%%%%%%%%%%%
% Create sensor task
data.th = 0;
data.d=0;
data.y=[0;0];
data.u=0;
data.thChanel=1;
data.dChanel=2;
offset = 0;
period = 0.010;
deadline=3*period;
prio = 3;
ttCreatePeriodicTask('sens_task', offset, period, prio, 'senscode', data);
ttCreateTask('act_task', deadline, 4, 'actcode', data);

% Create controller task
deadline = T_ech;
prio = 2;
ttCreateTask('pid_task', deadline, prio, 'ctrlcode', data);
% Optional disturbance task
if arg > 0
  offset = 0.0002;
  period = 0.007;
  prio = 1;
  ttCreatePeriodicTask('dummy', offset, period, prio, 'dummycode');
end

% Initialize network
ttCreateInterruptHandler('nw_handler', 2, 'msgRcvSensor');
ttCreateInterruptHandler('nw_handler', prio, 'msgRcvCtrl');
ttInitNetwork(3, 'nw_handler'); % node #2 in the network