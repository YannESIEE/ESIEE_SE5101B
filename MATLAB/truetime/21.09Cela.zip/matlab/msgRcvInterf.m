function [exectime, data] = msgRcvInterf(seg, data)

msg = ttGetMsg;
exectime = -1;

