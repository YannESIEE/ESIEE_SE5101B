function [exectime, data] = msgRcvSensor(seg, data)

ttCreateJob('act_task')
exectime = -1;
end
