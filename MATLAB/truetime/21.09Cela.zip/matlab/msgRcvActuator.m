function [exectime, data] = msgRcvActuator(seg, data)

ttCreateJob('act_task')
exectime = -1;
